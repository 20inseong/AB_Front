package com.example.fortest;

import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.CalendarView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    private int yeaR=0, montH=0, daY=0;
    private String timE;
    private CalendarView calendarView;
    private TextView monthlyInDay, monthlyInnum, monthlyOutDay, monthlyOutnum, weeklyInDay, weeklyInnum, weeklyOutDay, weeklyOutnum, dailyInDay, dailyInTime, dailyInnum, dailyOutDay, dailyOutTime, dailyOutnum;

    private LinearLayout monthInItems, monthOutItems, weekInItems, weekOutItems, dailyInOutitems, addbyreceipt, addbyhand;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        calendarView = findViewById(R.id.calendarView);

        //영수증 인식 버튼
        addbyreceipt = findViewById(R.id.addbyreceipt);
        addbyreceipt.setEnabled(false);
        addbyreceipt.setAlpha(0.5f);

        //수동 추가 버튼
        addbyhand = findViewById(R.id.addbyhand);
        addbyhand.setEnabled(false);
        addbyhand.setAlpha((0.5f));

        dailyInOutitems = findViewById(R.id.dailyinoutitems);

        // 캘린더 날짜 클릭 이벤트 처리
        calendarView.setOnDateChangeListener((view, year, month, dayOfMonth) -> {
            // 선택된 날짜 가져오기
            Calendar selectedDate = Calendar.getInstance();
            selectedDate.set(year, month, dayOfMonth);

            dailyInOutitems.removeAllViews();
            //서버에서 정보 가지고 와서 다시 세팅

            addbyreceipt.setEnabled(true);
            addbyreceipt.setAlpha(1.0f);
            addbyhand.setEnabled(true);
            addbyhand.setAlpha((1.0f));

            yeaR = year;
            montH = month;
            daY = dayOfMonth;

            // 날짜 형식 지정
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

            // 데이터 업데이트 (임시 데이터 사용)
            updateData(year,month+1,dayOfMonth);
        });
        addbyhand.setOnClickListener(v->{
            // Dialog 생성
            Dialog dialog = new Dialog(this);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE); // 타이틀 숨김
            dialog.setContentView(R.layout.hand_add); // 팝업창 레이아웃 설정
            dialog.setCancelable(true); // 외부 클릭 시 닫기 설정

            // 팝업 창 크기 설정 (가로, 세로 비율 조정)
            if (dialog.getWindow() != null) {
                dialog.getWindow().setLayout(
                        (int) (getResources().getDisplayMetrics().widthPixels * 0.9), // 가로 크기 (90%)
                        WindowManager.LayoutParams.WRAP_CONTENT // 세로는 내용에 맞춤
                );
            }

            final int[] settings={0};

            Switch outOffinOn = dialog.findViewById(R.id.toggle_switch);
            TextView onOfftext = dialog.findViewById(R.id.toggle_text);
            EditText getmoney = dialog.findViewById(R.id.moneywrote);

            outOffinOn.setOnCheckedChangeListener((buttonView, checkout)->{
                if (checkout) {
                    onOfftext.setText("수입 (스위치 off 시 지출로 변경)");
                    settings[0] = 1;
                } else {
                    onOfftext.setText("지출 (스위치 on 시 수입으로 변경)");
                    settings[0] = 0;
                }
            });

            ((TextView)dialog.findViewById(R.id.dateselected)).setText(yeaR+"/"+montH+"/"+daY);
            // 취소 버튼 클릭
            dialog.findViewById(R.id.cancel_button).setOnClickListener(action -> dialog.dismiss());

            // 저장 버튼 클릭
            dialog.findViewById(R.id.save_button).setOnClickListener(action -> {
                //시간 체크
                long currentTimetillSec = System.currentTimeMillis();
                SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", Locale.getDefault());
                timE = sdf.format(new Date(currentTimetillSec));
                String moneys = getmoney.getText().toString().trim();

                //저장하고 당일 리스트에 넣기
                addDailyList(settings[0], moneys, yeaR, montH+1, daY, timE);
                dialog.dismiss(); // 다이얼로그 닫기
            });

            // 팝업 창 띄우기
            dialog.show();

        });
    }

    //당일 리스트에 추가
    private void addDailyList(int settings, String money, int year, int month, int day, String time){
        dailyInOutitems = findViewById(R.id.dailyinoutitems);
        View dailyLayout = LayoutInflater.from(this).inflate(R.layout.daily_frame,dailyInOutitems,false);

        ImageView imgs = dailyLayout.findViewById(R.id.images);
        if (settings == 0) {
            imgs.setImageResource(R.drawable.red_icon);
        } else {
            imgs.setImageResource(R.drawable.blue_icon);
        }

        TextView ddays = dailyLayout.findViewById(R.id.dday);
        ddays.setText(year+"/"+month+"/"+day);

        TextView ddayhours = dailyLayout.findViewById(R.id.ddayhour);
        ddayhours.setText(time);

        TextView ddaywons = dailyLayout.findViewById(R.id.ddaywon);
        ddaywons.setText(money+"원");

        //클릭하면 밑에 삭제 버튼 나오게 하기

        dailyInOutitems.addView(dailyLayout);
    }



    // 날짜별 입출력 데이터 업데이트
    private void updateData(int year, int month, int day) {
        //날짜 기반으로 월간/주간/일간 입출금 데이터 가져오기
        int monthlyOutS = 1000;
        int monthlyInS = 2000;
        int weeklyOutS = 3000;
        int weeklyInS = 4000;

        //세팅
        //날짜/시간 받기
        monthlyInDay = findViewById(R.id.select_month_in);
        monthlyOutDay = findViewById(R.id.select_month_out);
        weeklyInDay = findViewById(R.id.select_week_in);
        weeklyOutDay = findViewById(R.id.select_week_out);

        //돈받기
        monthlyOutnum = findViewById(R.id.monthly_out_num);
        monthlyInnum = findViewById(R.id.monthly_in_num);
        weeklyOutnum = findViewById(R.id.weekly_out_num);
        weeklyInnum = findViewById(R.id.weekly_in_num);

        //레이아웃
        monthInItems = findViewById(R.id.monthly_initems);
        monthInItems.setVisibility(View.VISIBLE);
        monthOutItems = findViewById(R.id.monthly_outitems);
        monthOutItems.setVisibility(View.VISIBLE);
        weekInItems = findViewById(R.id.weekly_initems);
        weekInItems.setVisibility(View.VISIBLE);
        weekOutItems = findViewById(R.id.weekly_outitems);
        weekOutItems.setVisibility(View.VISIBLE);

        //월간 수입 출력
        monthlyInDay.setText(year+"년 "+month+"월 수입");
        monthlyInnum.setText(monthlyInS+"원");
        //월간 지출 출력
        monthlyOutDay.setText(year+"년 "+month+"월 지출");
        monthlyOutnum.setText(monthlyOutS+"원");

        //주간 수입 출력
        weeklyInDay.setText(year+"년 "+month+"월 "+day+"일 주간 수입");
        weeklyInnum.setText(weeklyInS+"원");
        //주간 지출 출력
        weeklyOutDay.setText(year+"년 "+month+"월 "+day+"일 주간 지출");
        weeklyOutnum.setText(weeklyOutS+"원");
    }
}
