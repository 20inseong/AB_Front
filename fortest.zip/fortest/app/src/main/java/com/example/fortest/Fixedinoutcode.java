package com.example.fortest;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class Fixedinoutcode extends AppCompatActivity {
    private LinearLayout outcontainer, incontainer, outaddbtn,inaddbtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fixed_in_out);

        outcontainer = findViewById(R.id.outcontainer);
        incontainer = findViewById(R.id.incontainer);

        outaddbtn = findViewById(R.id.outaddbtn);
        inaddbtn = findViewById(R.id.inaddbtn);

        //고정지출 스크롤뷰 세팅
        //서버에서 데이터 받아오기. 지금은 테스트 데이터. 걍 쓰레기값
        String outcontent = "고정 지출 항목";
        int outnum=0;
        String outdetails = "고정지출 상세항목";
        for(int i=0; i<8; i++){
            String stnum = String.valueOf(outnum);
            dataForScroll(outcontainer,outcontent,stnum,outdetails);
            outnum++;
        }

        //고정수입 스크롤뷰 세팅
        //서버에서 데이터 받아오기. 지금은 테스트 데이터. 걍 쓰레기값
        String incontent = "고정 수익 항목";
        int innum=0;
        String indetails = "고정수익 상세항목";
        for(int i=0; i<8; i++){
            String stnum = String.valueOf(innum);
            dataForScroll(incontainer,incontent,stnum,indetails);
            innum++;
        }

        //고정지출 쪽에서 추가하기 버튼 누르면 추가하는 창 뜨게하고 값 입력 끝나면 추가하기
        outaddbtn.setOnClickListener(v->{
            String nameofcontent = "고정 지출 추가";
            addLayoutSet(outcontainer,nameofcontent);
        });

        //고정수입 쪽에서 추가하기 버튼 누르면 추가하는 창 뜨게하고 값 입력 끝나면 추가하기
        inaddbtn.setOnClickListener(v->{
            String nameofcontent = "고정 수입 추가";
            addLayoutSet(incontainer,nameofcontent);
        });
    }

    //추가하는 창 세팅
    private void addLayoutSet(LinearLayout container,String nameofcontent){
        View inputLayout = LayoutInflater.from(this).inflate(R.layout.fixed_i_o_add, container, false);
        container.addView(inputLayout);

        Button okButton = inputLayout.findViewById(R.id.addbtn);
        Button cancleButton = inputLayout.findViewById(R.id.cancelbtn);

        //ImageView imageShow = inputLayout.findViewById(R.id.imageshow);

        TextView itemshow = inputLayout.findViewById(R.id.item1);
        itemshow.setText(nameofcontent);

        EditText inputName = inputLayout.findViewById(R.id.item2);
        inputName.requestFocus();
        EditText inputMon = inputLayout.findViewById(R.id.item3);
        EditText inputDetail = inputLayout.findViewById(R.id.item4);

        //취소 버튼 누르면 추가하는 창 없애고
        cancleButton.setOnClickListener(view->{
            container.removeView(inputLayout);
        });

        //확인 버튼 누르면 입력한 값들 가지는 항목 리스트에 넣음
        okButton.setOnClickListener(view -> {
            String namestring = inputName.getText().toString().trim();
            String monstring = inputMon.getText().toString().trim();
            String detailstring = inputDetail.getText().toString().trim();

            if ((!namestring.isEmpty())&&(!monstring.isEmpty())) {
                dataForScroll(container,namestring, monstring, detailstring);//필수 입력 항목에 빈칸이 없을 경우 받아온 데이터 리스트에 넣기
                container.removeView(inputLayout); // 입력창 삭제
            }
            else {
                //칸 채우라는 메시지 띄우기
                TextView warnmsg = findViewById(R.id.sendtoknow);
                StringBuilder missingFields = new StringBuilder();
                if(namestring.isEmpty()){
                    missingFields.append("항목, ");
                }

                if (monstring.isEmpty()){
                    missingFields.append("지출값, ");
                }

                if (missingFields.length() > 0) {
                    String missingText = missingFields.substring(0, missingFields.length() - 2);

                    // 경고 메시지 표시
                    warnmsg.setText("항목, 월 지출은 필수 입력 항목입니다. \n현재 " + missingText + "이 비어 있습니다. 채워주세요.");
                    warnmsg.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    //스크롤뷰에 넣을 데이터 세팅하고 리스트에 넣는 함수
    private void dataForScroll(LinearLayout container,String nameString, String monString, String detailString){
        //세팅
        View dataLayout = LayoutInflater.from(this).inflate(R.layout.f_i_o_frame,container,false);

        TextView firstChar = dataLayout.findViewById(R.id.firsticon);
        firstChar.setText(String.valueOf(nameString.charAt(0)));

        TextView upname = dataLayout.findViewById(R.id.item1);
        upname.setText(nameString);

        //ImageView imageContain = findViewById(R.id.imageshow);
        TextView downname = dataLayout.findViewById(R.id.item2);
        downname.setText(nameString);

        TextView numb = dataLayout.findViewById(R.id.item3);
        numb.setText("월 "+monString+"원");

        TextView detailcontent = dataLayout.findViewById(R.id.item4);
        detailcontent.setText(detailString);

        Button closeButton = dataLayout.findViewById(R.id.closebtn);
        Button deleteButton = dataLayout.findViewById(R.id.deletebtn);

        ImageView checkornot = dataLayout.findViewById(R.id.checkbtn1);
        ImageView showcheckornot = dataLayout.findViewById(R.id.checkbtn2);

        final boolean[] isImageVb = {true};

        checkornot.setOnClickListener(click->{
            if (isImageVb[0]){
                showcheckornot.setImageDrawable(null);
            } else{
                showcheckornot.setImageResource(R.drawable.check_icon);
            }
            isImageVb[0] = !isImageVb[0];
        });

        showcheckornot.setOnClickListener(click->{
            if(isImageVb[0]){
                showcheckornot.setImageDrawable(null);
            } else {
                showcheckornot.setImageResource(R.drawable.check_icon);
            }
            isImageVb[0] = !isImageVb[0];
        });

        LinearLayout allLayout, upLayout, downLayout;

        allLayout = dataLayout.findViewById(R.id.wholeframe);
        allLayout.setBackground(null);

        upLayout = dataLayout.findViewById(R.id.upper_layout);
        upLayout.setBackgroundColor(Color.parseColor("#f3eaff"));

        downLayout = dataLayout.findViewById(R.id.downable_layout);
        downLayout.setVisibility(View.GONE);

        //클릭하면 펼쳐지고 닫히고
        upLayout.setOnClickListener(click->{
            if(downLayout.getVisibility()==View.GONE){
                upLayout.setBackground(null);
                allLayout.setBackground(getResources().getDrawable(R.drawable.rounded_box));
                downLayout.setVisibility(View.VISIBLE);
            }
            else {
                upLayout.setBackgroundColor(Color.parseColor("#f3eaff"));
                allLayout.setBackground(null);
                downLayout.setVisibility(View.GONE);
            }
        });

        //닫기 버튼
        closeButton.setOnClickListener(click->{
            downLayout.setVisibility(View.GONE);
        });

        //삭제 버튼 누르면 리스트에서 없애기.
        deleteButton.setOnClickListener(click->{
            //진짜 삭제할건지 한 번 묻는 창 띄우고 취소하기 누르면 걍 창 없애고, 확인 누르면
            //확인 눌렀을 경우
            container.removeView(dataLayout);
        });

        //리스트에 넣기
        container.addView(dataLayout);
    }
}