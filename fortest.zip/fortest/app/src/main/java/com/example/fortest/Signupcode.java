package com.example.fortest;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class Signupcode extends AppCompatActivity {
    private EditText etId, etPw, etPwcheck, etUserName, etEmail;
    private LinearLayout btnSignUp;

    private TextView showWarningMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.signup);

        etId = findViewById(R.id.et_userid);
        etPw = findViewById(R.id.et_userpw);
        etPwcheck = findViewById(R.id.et_pwcheck);
        etUserName = findViewById(R.id.et_username);
        etEmail = findViewById(R.id.et_email);
        List<EditText> edTextList = new ArrayList<>();
        edTextList.add(etId);
        edTextList.add(etPw);
        edTextList.add(etPwcheck);
        edTextList.add(etUserName);
        edTextList.add(etEmail);

        btnSignUp = findViewById(R.id.signupbtn);

        showWarningMessage = findViewById(R.id.showwarningmsg);

        for (int i = 0; i < edTextList.size(); i++) {
            EditText currentEditText = edTextList.get(i);

            currentEditText.addTextChangedListener(new TextWatcher() {
                @Override
                public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                }

                @Override
                public void onTextChanged(CharSequence s, int start, int before, int count) {
                }

                @Override
                public void afterTextChanged(Editable s) {
                    updateState();
                }
            });
        }

        // 회원가입 버튼 클릭 시
        btnSignUp.setOnClickListener(v -> {
            //서버로 보내기
            sendtoServer();
        });
    }

    //버튼이랑 메시지 업데이트
    private void updateState(){
        // 버튼 비활성화 (반투명)
        btnSignUp.setEnabled(false);
        btnSignUp.setAlpha(0.5f);

        //상태 체크
        StringBuilder missingFields = new StringBuilder();

        //항목들 중 비어있는 항목이 있는지 체크
        if (etId.getText().toString().isEmpty()) {
            missingFields.append("아이디, ");
        }
        if (etPw.getText().toString().isEmpty()) {
            missingFields.append("비밀번호, ");
        }
        if (etPwcheck.getText().toString().isEmpty()) {
            missingFields.append("비밀번호 확인, ");
        }
        if (etUserName.getText().toString().isEmpty()) {
            missingFields.append("이름, ");
        }
        if (etEmail.getText().toString().isEmpty()) {
            missingFields.append("이메일, ");
        }

        //빈칸 존재 여부 확인
        if (missingFields.length() > 0) {
            String missingText = missingFields.substring(0, missingFields.length() - 2);

            // 경고 메시지 표시
            showWarningMessage.setText("모든 항목을 채워주세요. 비어있는 항목: " + missingText);
            showWarningMessage.setVisibility(View.VISIBLE);
        } else {
            //빈 항목 없을 경우 비밀번호 일치 여부 확인
            if (etPw.getText().toString().equals(etPwcheck.getText().toString())) {
                showWarningMessage.setVisibility(View.GONE);
                // 버튼 활성화 (불투명)
                btnSignUp.setEnabled(true);
                btnSignUp.setAlpha(1.0f);
            } else {
                showWarningMessage.setText("비밀번호 일치 여부를 확인해 주세요.");
                showWarningMessage.setVisibility(View.VISIBLE);
            }
        }
    }

    //서버 보내는 데이터 형식
    private void sendtoServer(){
        //각 항목별로 내용물 받기
        String id = etId.getText().toString();
        String password = etPw.getText().toString();
        String passwordCheck = etPwcheck.getText().toString();
        String name = etUserName.getText().toString();
        String email = etEmail.getText().toString();

        //서버로 데이터 보내기
        //

        //서버로 데이터 보내는 데 성공 시
        Toast toast = Toast.makeText(Signupcode.this, "",Toast.LENGTH_SHORT);
        LayoutInflater inflater = getLayoutInflater();
        View layout = inflater.inflate(R.layout.toast_layout, null);
        TextView toastMsg = layout.findViewById(R.id.toastMessage);
        toastMsg.setText("회원가입 완료");
        toast.setView(layout);
        toast.setGravity(Gravity.CENTER,0,0);
        toast.show();

        // 로그인으로 이동하고 지금 페이지 종료
        //!!!!!!!지금은 임시로 MainActivity.class로 이동, 추후 이동할 경로에 맞게 수정
        Intent intent = new Intent(Signupcode.this, MainActivity.class);
        startActivity(intent);
        finish();
    }
}

