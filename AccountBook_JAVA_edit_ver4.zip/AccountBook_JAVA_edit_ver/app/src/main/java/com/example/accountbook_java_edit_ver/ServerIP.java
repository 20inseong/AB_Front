package com.example.accountbook_java_edit_ver;

public class ServerIP {
    public static final String SERVER_IP = "http://10.0.2.2:8080/";
}