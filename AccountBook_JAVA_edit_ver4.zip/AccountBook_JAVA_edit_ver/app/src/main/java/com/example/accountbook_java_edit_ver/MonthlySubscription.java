package com.example.accountbook_java_edit_ver;

public class MonthlySubscription {
    private int subscription_id;
    private String subscription_item;
    private int price;
    private String category;
    private String billing_date;

    // 생성자
    public MonthlySubscription(int subscription_id, String subscription_item, int price, String category, String billing_date) {
        this.subscription_id = subscription_id;
        this.subscription_item = subscription_item;
        this.price = price;
        this.category = category;
        this.billing_date = billing_date;
    }

    // Getter와 Setter
    public int getSubscriptionId() { return subscription_id; }
    public void setSubscriptionId(int subscription_id) { this.subscription_id = subscription_id; }

    public String getSubscriptionItem() { return subscription_item; }
    public void setSubscriptionItem(String subscription_item) { this.subscription_item = subscription_item; }

    public int getPrice() { return price; }
    public void setPrice(int price) { this.price = price; }

    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getBillingDate() { return billing_date; }
    public void setBillingDate(String billing_date) { this.billing_date = billing_date; }
}

